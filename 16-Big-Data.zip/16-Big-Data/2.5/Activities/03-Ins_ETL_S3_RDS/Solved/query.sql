-- Query databse to check successful upload
SELECT * FROM active_user;

SELECT * FROM billing_info;

SELECT * FROM payment_info;
