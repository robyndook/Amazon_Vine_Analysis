# Everyone Do

* The instructor will show the class how to cleanup the AWS instance to avoid charges.

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.