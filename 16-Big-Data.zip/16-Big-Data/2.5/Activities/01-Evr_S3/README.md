# Everyone Do

* In this activity, you will create a PostgreSQL database in RDS.

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.